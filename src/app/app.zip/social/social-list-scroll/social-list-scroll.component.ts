import { Component, OnInit } from '@angular/core';

import { SocialService } from './../social.service';
@Component({
  selector: 'app-social-list-scroll',
  templateUrl: './social-list-scroll.component.html',
  styleUrls: ['./social-list-scroll.component.css']
})
export class SocialListScrollComponent implements OnInit {
  private _page: number = 1;
  private _fetchrows: number = 10;
  private _total: number;
  private socials = [];

  constructor(private socialService: SocialService) { }

  ngOnInit() {
    this.get(1,10);
  }

  get(page:number, count:number){
    this.socialService.getSocialList(page,count).subscribe((lst)=>{
        this.socials = lst.json().SSD;
        this._page = page;
        this._total  = lst.json().totalRows;
        console.log(lst.json());
    },(err)=>{
        console.log(err);
    })
}
}
