import { SocialListScrollComponent } from './social-list-scroll/social-list-scroll.component';

import { Routes, RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";

import { SocialService } from './social.service';
import { SocialListComponent } from './social-list.component';
import { PaginationModule } from '../core/pagination/pagination.module';


const socialRoute: Routes = [
  {path:'social/list',component:SocialListComponent},
  {path:'social/listscroll',component:SocialListScrollComponent}
];

@NgModule({
    declarations: [
      SocialListComponent,
      SocialListScrollComponent
    ],
    imports: [
      CommonModule,
      HttpModule,
      RouterModule.forChild(socialRoute),
      PaginationModule
    ],
    providers: [SocialService]
  })
  export class SocialModule { }